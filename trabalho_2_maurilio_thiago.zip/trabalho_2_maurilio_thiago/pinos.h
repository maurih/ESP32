#ifndef pinos_h
#define pinos_h

#define pwm_channel 0
#define mot_1 14
#define mot_2 27
#define res_1 26
#define res_2 25
#define temp 39
#define rele 4

#endif
